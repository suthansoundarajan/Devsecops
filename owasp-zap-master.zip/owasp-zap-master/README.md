Perform DAST scan using OWASP ZAP 
